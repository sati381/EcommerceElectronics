<footer class="footer bg-dark text-light py-3 fixed-bottom">
    <div class="container text-center">
        <p class="mb-0">E-store capstone @copyright2023</p>
    </div>
</footer>

<!-- </main>
<script src="../assets/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/perfect-scrollbar.min.js"></script>
  <script src="../assets/js/smooth-scrollbar.min.js"></script>
</body>

</html> -->