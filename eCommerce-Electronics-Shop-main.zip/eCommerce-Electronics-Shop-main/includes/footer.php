
        <footer class="footer bg-primary text-light py-3">
            <div class="container mb-2"style="margin: auto; width:50%">
                <ul class="list-unstyled text-center d-flex justify-content-between mt-3">
                    <li style="margin: 0; padding: 0;"><a href="index.php" class="text-light text-decoration-none">Home</a></li>
                    <li style="margin: 0; padding: 0;"><a href="shop.php" class="text-light text-decoration-none">Products</a></li>
                    <li style="margin: 0; padding: 0;"><a href="" class="text-light text-decoration-none">About Us</a></li>
                    <li style="margin: 0; padding: 0;"><a href="#" class="text-light text-decoration-none">Contact Us</a></li>
                </ul>
            </div>
            <div class="social-links mt-3 text-center">
                <a href="https://www.facebook.com/" class="text-light mx-2"><i class="fab fa-facebook-f"></i></a>
                <a href="https://twitter.com/" class="text-light mx-2"><i class="fab fa-twitter"></i></a>
                <a href="https://www.instagram.com/" class="text-light mx-2"><i class="fab fa-instagram"></i></a>
            </div>
            <div class="container">
                <p class="m-0 text-center text-white">Copyright &copy; Electronic e-store 2023</p>
            </div>
        </footer>
       
       </body>
      
   </html>
   